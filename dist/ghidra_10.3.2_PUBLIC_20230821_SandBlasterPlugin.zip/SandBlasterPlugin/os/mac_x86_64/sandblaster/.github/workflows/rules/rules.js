"use strict";

const rules = [
	require("./md101.js"),
	require("./md102.js"),
	require("./md103.js"),
	require("./md104.js"),
];
module.exports = rules;
