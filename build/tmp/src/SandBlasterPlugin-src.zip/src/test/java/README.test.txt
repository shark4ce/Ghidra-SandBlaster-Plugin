The "test" directory is intended to hold unit test cases.  The package structure within
this folder should correspond to that found in the "src" folder.
